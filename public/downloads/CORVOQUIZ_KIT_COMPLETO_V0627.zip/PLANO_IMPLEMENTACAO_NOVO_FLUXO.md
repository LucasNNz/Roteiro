# Plano de implementação — Novo fluxo CorvoQuiz

Bases: `CORVOQUIZ_ESPECIFICACAO_NOVO_FLUXO_APP_BRIDGE` e `CORVOQUIZ_MUDANCA_MODO_AUTOMATICO_ANALISTA`.

## Fase 1 — Fundação

- [x] Especialistas configuráveis: Analista, Refinador, Gerador, Fallback, Thumb e YouTube.
- [x] Jobs persistentes por 7 dias.
- [x] Manifestos estruturados e regra de arquivo real para Thumb/Refinador/Gerador.

## Fase 2 — Arquivos e ramos paralelos

- [x] Vercel Blob + `POST /api/corvo/arquivo`.
- [x] Thumb paralela e captura pelo Bridge.
- [x] YouTube/Metadados opcional em paralelo.
- [ ] Validar a captura da Thumb no deploy real com Blob conectado.

## Fase 3 — Collector → Analista → roteamento

## Alteração V0.6.27 — checkpoint fino da preparação do Analista

- [x] Persistir estágio `JOB_CREATED` ao criar o job do Analista.
- [x] Persistir `CANDIDATES_PREPARING` durante preparo/upload dos lotes.
- [x] Validar no servidor que todos os IDs possuem ao menos uma candidata antes do checkpoint reutilizável.
- [x] Persistir `CANDIDATES_STORED` antes da montagem do ZIP.
- [x] Persistir `ZIP_BUILDING` e `ZIP_SAVED`.
- [x] Criar `GET/POST /api/corvo/checkpoint` para reconciliação após F5/reabertura.
- [x] Falha em `CANDIDATES_STORED`/`ZIP_BUILDING` retoma somente `/api/corvo/pacote`, reutilizando os lotes no Blob/Redis.
- [x] Falha após `ZIP_SAVED` continua retentando somente o Analista.
- [x] Retry automático usa backoff 1 min → 2 min → 5 min → 10 min também para a montagem do pacote.
- [x] UI expõe `CHECKPOINT DO ANALISTA SALVO` e permite retomada manual sem Collector.

## Alteração V0.6.26 — checkpoint persistente antes do Analista

- [x] Após a consolidação, o ZIP do Analista fica salvo no Vercel Blob e referenciado no projeto.
- [x] Persistir `analysisJobId`, URL/nome do ZIP, IDs esperados, prompt, token e timestamps da tentativa.
- [x] Falha de Bridge/Analista não volta ao Collector nem refaz compressão/lotes.
- [x] Retry automático com backoff 1 min → 2 min → 5 min → 10 min.
- [x] Botão `PACOTE DO ANALISTA SALVO` permite reenvio manual imediato.
- [x] F5/reabertura preserva o checkpoint e retoma o timer do Analista.
- [x] Job do Analista pode ser resetado para retry sem remover o `COLLECTOR_ZIP` já anexado.
- [x] Automático Total permanece `RUNNING`/`ANALISTA` durante a espera e continua sozinho quando a análise terminar.

- [x] Job do Analista criado antes do transporte das imagens.
- [x] ZIP persistente anexado ao Corvo Analista.
- [x] Validação de IDs do manifesto.
- [x] `PASSOU` → Refinador leve.
- [x] `PASSOU_COM_RESSALVAS` → Refinador forte.
- [x] `NAO_PASSOU` → Gerador.
- [x] Arquivo real de origem anexado ao Refinador.
- [x] Arquivos finais de Refinador/Gerador capturados e persistidos.
- [x] Gerador com um worker global.


## Alteração V0.6.16 — retomada idempotente do pacote do Collector

- Corrige o erro recorrente `PACKAGE_ALREADY_RUNNING` após a coleta.
- O mesmo pacote da mesma produção pode ser solicitado novamente sem duplicar trabalho: o Collector retorna `resumed=true` e o app continua o polling.
- Se o estado `RUNNING/QUEUED` ficou órfão porque o offscreen worker desapareceu, o lock é liberado automaticamente.
- Se não houver progresso por 3 minutos, o pacote é considerado stale e pode ser reconstruído.
- O app também reconhece pacote legado ativo pelo mesmo `fileName + total` e retoma o acompanhamento.

## Alteração V0.6.15 — Automático Total real

- [x] Botão `INICIAR AUTOMÁTICO` movido para o topo, ao lado de `NOVA PRODUÇÃO`.
- [x] Clique no automático cria uma produção nova com `stage=IDEIA`.
- [x] Scout executa descoberta automática sem exigir escolha humana.
- [x] Scout é instruído a colocar sua recomendação principal como IDEIA 1.
- [x] App seleciona automaticamente a IDEIA 1 e preserva seu texto completo.
- [x] Roteirista recebe a ideia completa, não só título/tema.
- [x] Roteiro → Prompts → Collector → Analista → Refinador/Gerador → Fallback → Merge sem cliques intermediários.
- [x] Thumb e Metadados continuam paralelos.
- [x] ZIP final é gerado/baixado automaticamente.
- [x] Modo assistido continua em `NOVA PRODUÇÃO`.
- [x] Projeto interrompido oferece `RETOMAR ESTA PRODUÇÃO` apenas no próprio cartão.

## Alteração V0.6.11 — automático delegado ao Analista

- [x] Remover seleção visual automática do app.
- [x] No modo `AUTO`, incluir todas as candidatas retornadas pelo Collector.
- [x] Nomear candidatas de forma única por `ID + índice`.
- [x] Transportar `id` junto de cada `COLLECTOR_IMAGE`.
- [x] Separar o registro das candidatas do objeto principal do job para suportar lotes grandes.
- [x] Montar ZIP completo com índice `ID → candidatas`.
- [x] Atualizar Analista para `CORVO_IMAGE_ANALYSIS VERSION=1.1`.
- [x] Exigir `ARQUIVO=<nome exato>` em PASSOU/PASSOU_COM_RESSALVAS.
- [x] Resolver fisicamente os nomes escolhidos pelo Analista no armazenamento original do Collector.
- [x] Manter modo manual disponível.
- [x] Manter Refinador e Gerador em ramos paralelos após a análise.

## Fase 4 — Fallback

- [x] Detectar `FALHOU`, `ERROR_CODE`, `MOTIVO`.
- [x] `RETRY` / `NAO_RECUPERAVEL`.
- [x] Até duas novas tentativas.
- [x] Histórico por ID e tratamento manual quando necessário.

## Fase 5 — Consolidação

- [x] Validar todos os IDs finais.
- [x] Detectar ausentes/duplicados/formato inválido.
- [x] ZIP final com imagens, thumb, metadados, análise e histórico.
- [x] Aguardar os dois ramos antes de concluir.
- [ ] Reidratar automaticamente pollers de jobs após F5/reabertura do app.

## Fora do escopo

- Upload/publicação automática no YouTube.
- Métricas pós-publicação.

## OTIMIZAÇÃO V0.6.13 — SHORTLIST + BATCH UPLOAD

- [x] Limitar o automático a até 10 candidatas por ID por padrão, configurável de 1 a 30.
- [x] Preservar o Analista como único decisor visual da imagem vencedora.
- [x] Agrupar cópias de análise em ZIPs de até 36 candidatas.
- [x] Preparar lotes com 8 workers.
- [x] Enviar cada lote com retry automático.
- [x] Registrar dezenas de candidatas no Redis com um único HSET por lote.
- [x] Montar o ZIP final do Analista baixando cada lote apenas uma vez.
- [x] Preservar compatibilidade com candidatas individuais das versões anteriores.

## HOTFIX V0.6.14 — BUILD TYPESCRIPT

- `runAutomaticSpecialist` valida `jobId` após criação/recuperação.
- O loop de polling usa `activeJobId:string`, eliminando o erro de build em `encodeURIComponent(jobId)`.
- Sem alteração funcional no pipeline ou nas extensões.



## OTIMIZAÇÃO V0.6.17 / COLLECTOR V0.8.0
- Busca limitada a 20 candidatas únicas por ID.
- GOOGLE/PINTEREST: teto 20. MIXED: 10 + 10.
- A rolagem para assim que a cota é atingida.
- Shortlist para Analista continua padrão 10/ID.
